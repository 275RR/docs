
# Burgenland Bunch Editor v3

**Improved Workflow for Village and Surname Editors**

The BB Editor v3 is a collection of tools to simplify and/or automate the process of making changes to webpages on the BB website. More details below.

</br>

## The Old Way vs The New Way

Members submit new data and/or changes. The editor looks through the html files (which are numerous and long) and inserts the changes directly into the webpages. This process is straight-forward and requires low technical knowledge. However, this process is highly prone to errors, tedious, and difficult to understand changes at a macro level.

Now, the editor uses Excel to insert changes into the Village and Surname data. Next, the editor uses BB Editor v3 (a simple GUI tool) to manage version control and to convert the Excel data into webpages, backup data, and upload the new webpages to the BB website. Although, this code does create technical debt.

*However, since the end result is the same using either method (old or new), an editor could use the Old Way at any time if needed.*

Some features:

1. uses Excel as a light database
2. Excel for its data entry tools
3. builds webpages from Excel data using templates
4. new webpage design with mobile support
5. backup editor files and data
6. upload webpages to BB website
7. push/pull this project to GitHub

</br>

## Installation for Windows

Note: need an active GitHub account with access to private BB repo

Note: "repo" is short for repository, in this case, GitHub code repo

- Clone or Download Code from GitHub ([repo link: BB-Editor-V3-main](https://github.com/275RR/BB-Editor-V3))
  - download by clicking the green `Code` button on GitHub
  - click download ZIP
  - unzip to a location of your choice (Do NOT unzip to protected folders such as Documents, Favorites, Desktop, etc)
- Install uv (Package Manager for Python)
  - open powershell by right-clicking on Windows Start button then click powershell/terminal
  - copy/paste from below and press Enter
  - close powershell

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

- Install Git
  - navigate to BB-Editor-V3-main folder on local machine
  - right-click on `install-git.ps1` and select "Run with PowerShell"
  - Note!!! If terminal opens and instantly closes WITHOUT your input, follow steps below
    - open powershell by right-clicking on Windows Start button then click powershell/terminal
    - in file explorer URL bar, copy/paste the full path to your BB-Editor-V3-main folder into powershell
      - type cd followed by a space
      - paste the full path to your bb editor folder
      - put quote marks at start of full path and end of full path and press Enter
      - see first example below
    - copy/paste the powershell command below (the second example) into the terminal and press Enter
  - Optional: for manual install of Git, go to [Git Downloads](https://git-scm.com/install/windows)

```powershell
cd "C:\<some folder>\<another folder>\BB-Editor-V3-main"
```

```powershell
powershell -ExecutionPolicy ByPass .\install-git.ps1
```

- Run BB Editor V3
  - navigate to BB-Editor-V3-main/App/ folder on local machine
  - Double-Click `Run BBeditor.bat`
  - Note: On first run, uv will install any needed packages
  - Note: When you attempt your first Pull in the GitHub Pull tab, you should get a yellow box warning about local changes and a green box for success. This is normal.
- Installation Complete.

</br>

### BB Editor Directory Tree

```text
BB-Editor-V3-main/
├── App/
│   ├── .streamlit/
|   │   ├── modules/                          (app function library)
|   │   │   └── config.py
|   │   │   └── convert_member_to_html.py
|   │   │   └── convert_surname_to_html.py
|   │   │   └── convert_village_to_html.py
|   │   │   └── email_dropdown_data.py
|   │   │   └── email.py
|   │   │   └── ftp.py
|   │   │   └── github.py
|   │   │   └── zip.py
|   │   ├── pages/                            (app webpages)
|   │   │   └── settings_backup.py
|   │   │   └── settings_email.py
|   │   │   └── settings_ftp.py
|   │   │   └── settings_github.py
|   │   │   └── tools_BBeditor.py
|   │   ├── temp/                             (app temp email files for Monthly Backups)
|   │   ├── defaults.toml                     (default app settings)
|   │   ├── secrets.toml                      (private user app settings)
│   ├── templates/
│   │   └── Jinja templates to create BB webpages
│   ├── webpages/                             (file/folder structure as on BB website)
│   │   ├── Chroniks/
│   │   │   └── BB village history
│   │   ├── CommonFiles/
│   │   │   └── BB website webfiles
│   │   ├── Members/
│   │   │   └── BB Members webfiles
│   │   ├── Surnames/
│   │   │   └── BB Surnames webfiles
│   │   ├── Villages/
│   │   │   └── BB Villages webfiles
│   │   ├── .htaccess
│   │   └── bb.ico
│   ├── 04 Res - 07 Sur - 02 Chg.file         (Note for the New section on Surnames Homepage)
│   ├── BBeditor.py                           (entry point for Streamlit app)
│   ├── blue_MasterList.xlsx
│   ├── blue_Members.xlsx
│   ├── blue_Surnames.xlsx
│   ├── blue_Villages.xlsx
│   └── Run BBeditor.bat                      (**START HERE** - calls BBeditor.py)
├── Monthly Backups/
│   └── Zip Archive of the App folder
├── Tutorial/
│   └── Files and images                      (used by this README.md)
├── .gitignore                                (files/folder to ignore when push to Github)
├── .python-version                           (for uv package manager)
├── README.md
├── Read Me.rtf
├── install-git.ps1                           (git install helper script)
├── pyproject.toml                            (for uv package manager)
└── uv.lock                                   (for uv package manager)
```

</br>

## Using BB Editor (Basic introduction)

**Note: See BB-Editor-V3-main/`Read Me.rtf` for detailed workflows**

**Note: The Editor tool tabs are in the order of your workflow.**

**Note: GitHub Pull latest changes BEFORE making any changes to Excel, Data, or Code. After all changes using Excel or BB Editor are done, Push changes to GitHub. The App will remind you.**

</br>

1. Double-click on the `Run BBeditor.bat` file to launch the BB Editor tool.
![BB Editor Run Image](/Tutorial/bat.png)

</br>

2. Follow the instructions to configure all of the BB Editor's settings. This only needs to be completed once.
![BB Editor Settings Image](/Tutorial/editorSettings.png)
SSH Format to connect to this repo on GitHub. </br>
**git@github.com: <REPO_USERNAME>/<REPO_NAME>.git** </br>
You could upload this code under your own GitHub account.
![BB Editor Github Settings Image](/Tutorial/editorSettingsGithub.png)

</br>

3. Click `Pull from GitHub` on the "GitHub Pull" tab as the first step of your workflow each time.
![BB Editor Github Pull Image](/Tutorial/editorPull.png)

</br>

4. Open the `Surnames and/or Villages Excel file` and make the needed changes. Use "Email Viewer" tab to help. Repeat until all changes are done. **IMPORTANT: Save and close Excel before the next step.**
![Excel Image](/Tutorial/excel.png)

</br>

5. Click on the "Convert" tab, select which Excel files to convert to webpages, and click `Create Webpages`.
![BB Editor Convert Image](/Tutorial/editorConvert.png)

</br>

6. Click on the "Backup" tab and click `Create Backup`.
![BB Editor Backup Image](/Tutorial/editorBackup.png)

</br>

7. Click on the "Upload" tab, select which webpages to upload, and click `Upload to BB Website`.
![BB Editor Upload Image](/Tutorial/editorUpload.png)

</br>

8. Click on the "GitHub Push" tab, enter a message about your changes, and click `Push to GitHub`.
![BB Editor Github Push Image](/Tutorial/editorPush.png)

</br>

## Programming References and Tools
- Burgenland Bunch
  - [BB-Editor-V3-main](https://github.com/275RR/BB-Editor-V3)
  - [BB Surnames](https://www.the-burgenland-bunch.org/Surnames/surnames.html)
  - [BB Villages](https://www.the-burgenland-bunch.org/Villages/Villages.htm)
  - [BB test/Members](https://www.the-burgenland-bunch.org/test/Members/members.html)

- Other Software
  - [Version Control - Git](https://git-scm.com/install/windows)
  - [Python Package Manager - uv](https://docs.astral.sh/uv/)
  - [Python Library - Streamlit](https://docs.streamlit.io/library/get-started)
  - [Python Library - Jinja](https://jinja.palletsprojects.com/en/stable/)
  - [Python Library - Pandas](https://pandas.pydata.org/)
  - [Python Library - OpenPyXL](https://openpyxl.readthedocs.io/en/stable/)
  - [Markdown Guide](https://www.markdownguide.org/basic-syntax/)
  - [Online Directory Tree Maker](https://tree.nathanfriend.io/?s=(%27options!(%27fancy!true~fullPath!false~traXingSlash!true~rootDot!false)~W(%27W%27YEN%20V39App*modulGzPython%20scripts*Q5Jinja%20QqpagGzCommonFXe8qsite6H8Hs6Ie8IG6Ke8KG6.htaccGszbb.ico*04%20RGU7%20SurU2%20Chg.fXe*BBeN.pyLHsOLIGOLKGO*Run%20BBeN.bat9Monthly%20Backups*Zip%20Archive%20of%20the%20App%20folder9Tutorial*FXG%20and%20imagG%20for%20README9README.md%27)~version!%271%27)*955%20%206%20qfXGz8sz5Y9%5Cn5GesHMemberISurnamKVXlagL*blue_NditorO.xlsxQtemplatG*U%20-%200Wsource!XilYBB%20qwebz*5%01zqYXWUQONLKIHG9865*)
